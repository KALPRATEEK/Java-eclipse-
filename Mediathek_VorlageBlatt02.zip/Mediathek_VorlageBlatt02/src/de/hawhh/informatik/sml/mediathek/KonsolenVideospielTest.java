package de.hawhh.informatik.sml.mediathek;


import static org.junit.Assert.assertEquals;

import org.junit.Test;


/**
 */
public class KonsolenVideospielTest extends AbstractVideospielTest
{
    private static final String KOMMENTAR = "Kommentar";
    private static final String TITEL = "Titel";
    private static final String SYSTEM = "System";
    private KonsolenVideospiel _videoSpiel;

    public KonsolenVideospielTest()
    {
        _videoSpiel = getMedium();
    }

    @Test
    public void testeVideospiel()
    {
        super.testeVideospiel();
    }

   
    protected KonsolenVideospiel getMedium()
    {
        return new KonsolenVideospiel(TITEL, KOMMENTAR, SYSTEM);
    }

    @Test
    public final void testSetKommentar()
    {
        super.testSetKommentar();
    }

    @Test
    public final void testSetTitel()
    {
        super.testSetTitel();
    }

    @Test
    public void testMietgebuehr()
    {
        super.testMietgebuehr();
        assertEquals(_videoSpiel.berechneMietgebuehr(5), Geldbetrag.get(900));
        assertEquals(_videoSpiel.berechneMietgebuehr(7), Geldbetrag.get(1600));
        assertEquals(_videoSpiel.berechneMietgebuehr(8), Geldbetrag.get(1600));
        assertEquals(_videoSpiel.berechneMietgebuehr(12), Geldbetrag.get(3000));
        assertEquals(_videoSpiel.berechneMietgebuehr(13), Geldbetrag.get(3000));
        assertEquals(_videoSpiel.berechneMietgebuehr(17), Geldbetrag.get(3700));
        assertEquals(_videoSpiel.berechneMietgebuehr(18), Geldbetrag.get(4400));
        assertEquals(_videoSpiel.berechneMietgebuehr(22), Geldbetrag.get(5100));
    }

}
