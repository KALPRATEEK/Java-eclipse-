package de.hawhh.informatik.sml.mediathek;

public class PCVideospiel extends AbstractVideospiel
{
    public PCVideospiel(String text, String kommentar, String system)
    {
        super(text, kommentar, system);
    }

    @Override
    public int  getPreisNachTagen(int tage)
    {
        if (tage <= 7)
        {
            return 0;
        }
        int gebuehren = (tage - 3) / 5;
        return  gebuehren * 500;
    }

 	
}
