package de.hawhh.informatik.sml.mediathek;

public abstract class AbstractMedium {

    	
    	    /**
    	     * Ein Kommentar zum Medium
    	     */
    	    private String _kommentar;

    	    /**
    	     * Der Titel des Mediums
    	     * 
    	     */
    	    private String _titel;
    	    
    	

    	    /**
    	     * Initialisiert ein neues Exemplar.
    	     * 
    	    
    	     * 
    	     * @require titel != null
    	     * @require kommentar != null
    	     * @require interpret != null
    	     * @require spiellaenge > 0
    	     * 
    	     * @ensure getTitel() == titel
    	     * @ensure getKommentar() == kommentar
    	     * @ensure getInterpret() == interpret
    	     * @ensure getSpiellaenge() == spiellaenge
    	     */
    	    protected AbstractMedium(String titel, String kommentar)
    	    {
    	        assert titel != null : "Vorbedingung verletzt: titel != null";
    	        assert kommentar != null : "Vorbedingung verletzt: kommentar != null";
    	       
    	        _titel = titel;
    	        _kommentar = kommentar;
    	    
    	    }
    	    
    	    public  String getTitel()
    	    {
    	    	return _titel;
    	    }
    	    
    	    
    	   public String getKommentar() 
    	   {
    		   
    		   return _kommentar;
    	   }
    	   
    	   public String getFormatiertenString()
    	   {
    		   String format = "%s , %s";
    		   return String.format(format,getTitel(),getKommentar());
    		   
    	   }
    	   
    	   public Geldbetrag berechneMietgebuehr(int mietTage) {
               if (mietTage <= 0) {
           // negative or zero rental period is not allowed
           throw new AssertionError("Invalid rental period: " + mietTage);
       } 
       Geldbetrag betrag=Geldbetrag.get(mietTage*300);
      
       
       return betrag;
   }
    	   
    	   /** 
    	     * Ändert den Titel
    	     * 
    	     * @param titel Der Titel des Mediums
    	     * 
    	     * @require titel != null
    	     * @ensure getTitel() == titel
    	     */
    	    public void setTitel(String titel)
    	    {
    	        assert titel != null : "Vorbedingung verletzt: titel != null";
    	        _titel = titel;
    	    }
    	    
    	    /**
    	     * Ändert den Kommentar
    	     * 
    	     * @param kommentar Der Kommentar des Mediums
    	     * 
    	     * @require kommentar != null
    	     * @ensure getkommentara() == kommentar
    	     */
    	    public void setKommentar(String kommentar)
    	    {
    	        assert kommentar != null : "Vorbedingung verletzt: kommentar != null";
    	        _kommentar = kommentar;
    	    }
    	    
    	    
  }
