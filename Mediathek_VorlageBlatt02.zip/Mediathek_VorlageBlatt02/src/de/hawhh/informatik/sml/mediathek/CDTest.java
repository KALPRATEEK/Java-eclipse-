package de.hawhh.informatik.sml.mediathek;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class CDTest extends AbstractMediumTest
{
    private static final String KOMMENTAR = "Kommentar";
    private static final String TITEL = "Titel";
    private static final String CD_BEZEICHNUNG = "CD";
    private static final String INTERPRET = "CD Interpret";
    private static final int LAENGE = 100;
    private CD _cd1;

    public CDTest()
    {
        _cd1 = getMedium();
    }

    @Test
    public void testGetMedienBezeichnung()
    {
        String cdBezeichnung = CD_BEZEICHNUNG;
        assertEquals(cdBezeichnung, _cd1.getMedienBezeichnung());
    }

    @Test
    public void testKonstruktor()
    {
        super.testKonstruktor();
        assertEquals(LAENGE, _cd1.getSpiellaenge());
        assertEquals(INTERPRET, _cd1.getInterpret());
    }

    @Test
    public final void testSetter()
    {
        super.testSetter();
        _cd1.setInterpret("Interpret2");
        assertEquals(_cd1.getInterpret(), "Interpret2");
        _cd1.setSpiellaenge(99);
        assertEquals(_cd1.getSpiellaenge(), 99);
    }

    @Test
    /*
     * Von ein und der selben CD kann es mehrere Exemplare geben, die von
     * unterschiedlichen Personen ausgeliehen werden können.
     */
    public void testEquals()
    {
        super.testEquals();
    }
  
    @Test
    public final void testGetFormatiertenString()
    {
    
    	Medium medium = getMedium();
        assertNotNull(medium.getFormatiertenString());
    
    }
   
    @Test
    public void testMietgebuehr()
    {
    assertEquals(_cd1.berechneMietgebuehr(3),Geldbetrag.get(3 * 300));
    assertEquals(_cd1.berechneMietgebuehr(27),Geldbetrag.get(27 * 300));
    }
    
    

    protected CD getMedium()
    {
        return new CD(TITEL, KOMMENTAR, INTERPRET, LAENGE);
    }

}
