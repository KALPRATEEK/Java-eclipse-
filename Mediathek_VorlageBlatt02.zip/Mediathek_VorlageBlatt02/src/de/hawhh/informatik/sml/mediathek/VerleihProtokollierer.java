package de.hawhh.informatik.sml.mediathek;


import java.io.FileWriter;
import java.io.IOException;


/**
 * Gibt die Informationen vom Medium aus und das Datum an dem es Ausgeliehen
 * wurde bzw zurückgegeben wurde.
 * 
 * @return Schreibt die Informationen auf eine Datei. Es kann eine Exception
 *         geworfen werden wenn die Datei nicht erreichbar ist.
 * 
 */
public class VerleihProtokollierer
{
	 
	
	   private FileWriter writer;
	    
    public enum VerleihEreignis
    {
        AUSGELIEHEN, ZURUECKGEGEBEN
    }
    
//    public VerleihProtokollierer() throws ProtokollierException
//    {
//        try {
//            writer = new FileWriter("./protokoll.txt");
//        } catch (IOException e) {
//            throw new ProtokollierException("Fehler beim Öffnen der Protokolldatei");
//        }
//    }
       
    /* 
     @require String ereignis !=null oder "" sein.
     Moegliche String koennte sein, "Ausleih", "Rueckgabe".
     @require verleihkarte !=null

     * */
    
     
    public static void protokolliere(String ereignis, Verleihkarte verleihkarte) throws ProtokollierException
    {
        try (FileWriter filewriter = new FileWriter("./protokoll.txt", true))
        {
            filewriter.write(ereignis);
            
            filewriter.close();
        } catch (IOException e)
        {
            throw new ProtokollierException(e.getMessage());
        }

    
    }
    
        

    
}
    
    
    


