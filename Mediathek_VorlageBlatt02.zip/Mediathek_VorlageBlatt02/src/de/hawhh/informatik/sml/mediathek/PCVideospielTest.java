package de.hawhh.informatik.sml.mediathek;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PCVideospielTest extends AbstractVideospielTest
{
    private static final String KOMMENTAR = "Kommentar";
    private static final String TITEL = "Titel";
    private static final String BEZEICHNUNG = "Videospiel";
    private static final String SYSTEM = "System";
    private PCVideospiel _videoSpiel;

    public PCVideospielTest()
    {
        _videoSpiel = getMedium();
    }

    @Test
    public void testeVideospiel() 
    {
        super.testeVideospiel();
    }

    @Test
    public void testGetMedienBezeichnung()
    {
        assertEquals(BEZEICHNUNG, _videoSpiel.getMedienBezeichnung());
    }

    protected PCVideospiel getMedium()
    {
        return new PCVideospiel(TITEL, KOMMENTAR, SYSTEM);
    }

    @Test
    public final void testSetKommentar()
    {
        super.testSetKommentar();
    }

    @Test
    public final void testSetTitel()
    {
        super.testSetTitel();
    }
    
    @Test
    public void testMietgebuehr()
    {
    super.testMietgebuehr();
    assertEquals(_videoSpiel.berechneMietgebuehr(5),Geldbetrag.get(200));
    assertEquals(_videoSpiel.berechneMietgebuehr(7),Geldbetrag.get(200));
    assertEquals(_videoSpiel.berechneMietgebuehr(8),Geldbetrag.get(700));
    assertEquals(_videoSpiel.berechneMietgebuehr(12),Geldbetrag.get(700));
    assertEquals(_videoSpiel.berechneMietgebuehr(13),Geldbetrag.get(1200));
    assertEquals(_videoSpiel.berechneMietgebuehr(17),Geldbetrag.get(1200));
    assertEquals(_videoSpiel.berechneMietgebuehr(18),Geldbetrag.get(1700));
    assertEquals(_videoSpiel.berechneMietgebuehr(22),Geldbetrag.get(1700));
    }

}
