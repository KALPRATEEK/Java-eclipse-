package de.hawhh.informatik.sml.mediathek;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public abstract class AbstractMediumTest
{
    private static final String KOMMENTAR = "Kommentar";
    private static final String TITEL = "Titel";
    private AbstractMedium _abstractMedium1;
    private AbstractMedium _abstractMedium2;
   
   protected AbstractMediumTest()
    {
        _abstractMedium1 = getMedium();
        _abstractMedium2 = getMedium();
    }

    @Test
    public void testKonstruktor()
    {
        assertEquals(TITEL, _abstractMedium1.getTitel());
        assertEquals(KOMMENTAR, _abstractMedium1.getKommentar());
 
    }

    @Test
    public void testSetter()
    {
        _abstractMedium1.setTitel("Titel2");
        assertEquals(_abstractMedium1.getTitel(), "Titel2");
        _abstractMedium1.setKommentar("Kommentar2");
        assertEquals(_abstractMedium1.getKommentar(), "Kommentar2");
    }

    @Test
    public void testEquals()
    {
        assertFalse("Mehrere Exemplare der gleichen CD sind ungleich",
                _abstractMedium1.equals( _abstractMedium2));
        assertTrue("Dasselbe Exemplare der gleichen CD ist gleich",
                _abstractMedium1.equals(_abstractMedium1));
    }
    
   
    
    abstract protected AbstractMedium getMedium();
    
    
    //test negative Oder 0 wert fuer BerechneMietGebuehr. 
    @Test(expected=AssertionError.class)
    public void negative()
    {
     assertEquals(_abstractMedium2.berechneMietgebuehr(-3),Geldbetrag.get(-3 * 300));
     assertEquals(_abstractMedium2.berechneMietgebuehr(0),Geldbetrag.get(0 * 300));
    }
   
}
