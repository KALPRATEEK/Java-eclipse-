package de.hawhh.informatik.sml.mediathek;
public class KonsolenVideospiel extends AbstractVideospiel {

	
    public KonsolenVideospiel(String titel, String kommentar, String system) {
        super(titel, kommentar, system);
    }

   
   
        
          
    @Override
    public int getPreisNachTagen(int tage)
    {

        int gebuehren = tage / 3;
        return  gebuehren * 700;
    
    }



 


	  
    }

    
    
    	


