package de.hawhh.informatik.sml.mediathek;


/**
 * {@link AbstractVideospiel} ist ein {@link Medium} mit einer zusätzlichen
 * Informationen zum kompatiblen System.
 * 
 * @author SE2-Team, PR2-Team, PR2-Team
 * @version SoSe 2023
 */
public abstract class AbstractVideospiel extends AbstractMedium implements Medium 
{
    /**
     * Das System, auf dem das Spiel lauffähig ist
     */
    private String _system;

    /**
     * Der Basispreis, wenn man ein Medium ausleiht
     */
   protected static final int BASISPREIS = 200;

    /**
     * Initialisiert ein neues Videospiel.
     * 
     * @param titel Der Titel des Spiels
     * @param kommentar Ein Kommentar zum Spiel
     * @param system Die Bezeichnung des System
     * 
     * @require titel != null
     * @require kommentar != null
     * @require system != null
     * 
     * @ensure getTitel() == titel
     * @ensure getKommentar() == kommentar
     * @ensure getSystem() == system
     */
    protected AbstractVideospiel(String titel, String kommentar, String system)
    {
        super(titel, kommentar);
        assert system != null : "Vorbedingung verletzt: system != null";
        _system = system;
    }

    @Override
    public String getMedienBezeichnung()
    {
        return "Videospiel";
    }

    /**
     * Gibt das System zurück, auf dem das Spiel lauffähig ist.
     * 
     * @return Das System, auf dem das Spiel ausgeführt werden kann.
     * 
     * @ensure result != null
     */
    public String getSystem()
    {
        return _system;
    }

    @Override
    public String toString()
    {
        return getFormatiertenString();
    }
    /**
     * Gibt die Informationen vom Medium aus.
     * 
     * @return Informationen auf dem Medium.
     */
    @Override
    public String getFormatiertenString()
    {
        return getMedienBezeichnung()+ ","+ super.getFormatiertenString() + "    "
                + "System: " + _system + "\n";
    }

/*
    Die Methode berechneMietgebuehr(int) 
    in der Klasse AbstractVideospiel ist die Schablonenmethode, 
    da sie den Ablauf der Berechnung für die Mietgebühr vorgibt und die 
    konkreten Schritte von den Subklassen implementiert werden.
*/

    /**
     * @return Mietgebühr für das Medium.
     */
    public Geldbetrag berechneMietgebuehr(int mietTage)
     {	
     int total =getPreisNachTagen(mietTage)+BASISPREIS;
    	return Geldbetrag.get(total);
    	
     }
 
 
/* 
    Die abstrakte Methode getPreisNachTagen(int) in der Klasse AbstractVideospiel 
    und die Implementierungen in den Subklassen PCVideospiel und KonsolenVideospiel sind Einschub-Operationen, 
    da sie von der Schablonenmethode aufgerufen werden
    und den spezifischen Preisanteil für das jeweilige Videospiel liefern.  
  */



    /**
     * @return Preis vom Medium nach anzahl der Tage.
     */
 
   abstract public int getPreisNachTagen(int tage);
}
