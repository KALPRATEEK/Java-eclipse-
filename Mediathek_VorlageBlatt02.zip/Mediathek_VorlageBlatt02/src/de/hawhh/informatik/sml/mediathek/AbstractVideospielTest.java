package de.hawhh.informatik.sml.mediathek;

import static org.junit.Assert.assertEquals;

import org.junit.Test;



public abstract class AbstractVideospielTest extends AbstractMediumTest
{
    private static final String SYSTEM = "System";
    private AbstractVideospiel _videoSpiel;

    public AbstractVideospielTest()
    {
        _videoSpiel = getMedium();
    } 
    @Test
    public void testeVideospiel()
    {
        super.testKonstruktor();
        assertEquals(SYSTEM, _videoSpiel.getSystem());
    }

   
    abstract protected AbstractVideospiel getMedium();

    @Test
    public void testSetKommentar()
    {
        super.testSetter();
    }

    @Test
    public void testSetTitel()
    {
        super.testSetter();
    }
    
    
    public void testMietgebuehr()
    {
    assertEquals(_videoSpiel.berechneMietgebuehr(1),Geldbetrag.get(200));
    assertEquals(_videoSpiel.berechneMietgebuehr(2),Geldbetrag.get(200));
    }
  
}
