import java.util.List;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;

/**
 * Ein MedienDetailAnzeigerWerkzeug ist ein Werkzeug um die Details von Medien
 * anzuzeigen.
 * 
 * @author SE2-Team, PM2-Team
 * @version SoSe 2023
 */
class MedienDetailAnzeigerWerkzeug
{
    private MedienDetailAnzeigerUI _ui;

    /**
     * Initialisiert ein neues MedienDetailAnzeigerWerkzeug.
     */
    public MedienDetailAnzeigerWerkzeug()
    {
        _ui = new MedienDetailAnzeigerUI();
    }

    /**
     * Setzt die Liste der Medien deren Details angezeigt werden sollen.
     * 
     * @param medien Eine Liste von Medien.
     * 
     * @require (medien != null)
    
    public void setMedien(List<Medium> medien)
    {
       
        TextArea selectedMedienTextArea = _ui.getMedienAnzeigerTextArea();   The first line of the method initializes a TextArea object from the user interface using a reference variable _ui and the method getMedienAnzeigerTextArea().
        selectedMedienTextArea.setText("");
       
        List <Medium> m =medien;
        

        for (Medium medium : medien)
         assert medien != null : "Vorbedingung verletzt: (medien != null)";
         {
            if (medium instanceof CD) {
                 CD cd = (CD) medium;
                selectedMedienTextArea.appendText("CD-Titel: " + cd.getTitel() + "\n");
                selectedMedienTextArea.appendText("kommentar: " + cd.getKommentar() + "\n");
                selectedMedienTextArea.appendText("Interpret:"  + cd.getInterpret() + "\n");
                selectedMedienTextArea.appendText("spiellange:"  + cd.getSpiellaenge() + "\n");
                selectedMedienTextArea.appendText("\n");
            }
            else if (medium instanceof DVD) 
            {
                DVD dvd = (DVD) medium;
                selectedMedienTextArea.appendText("DVD-Titel: " + dvd.getTitel() + "\n");
                selectedMedienTextArea.appendText("kommentar: " + dvd.getKommentar() + " \n");
                selectedMedienTextArea.appendText("Regisseur: " + dvd.getRegisseur() + "\n");
               
                selectedMedienTextArea.appendText("Laufzeit: " + dvd.getLaufzeit() + " Minuten\n");
               
                selectedMedienTextArea.appendText("\n");
            } 
            
            else if (medium instanceof Videospiel) {
                Videospiel videospiel = (Videospiel) medium;
                selectedMedienTextArea.appendText("Videospiel-Titel: " + videospiel.getTitel() + "\n");
                selectedMedienTextArea.appendText("kommentar: " + videospiel.getKommentar() + "\n");
                selectedMedienTextArea.appendText("System: " + videospiel.getSystem() + "\n");
                selectedMedienTextArea.appendText("\n");
            }
        }
        	
        	
        
      
        
    }
     */
    
    public void setMedien(List<Medium> medien)
    {
        
        TextArea selectedMedienTextArea = _ui.getMedienAnzeigerTextArea();
        selectedMedienTextArea.setText("");
       
        for (Medium medium : medien) {
        	assert medien != null : "Vorbedingung verletzt: (medien != null)";
        	selectedMedienTextArea.appendText(medium.getFormatiertenString());
            selectedMedienTextArea.appendText("\n");
        }        	
    }
    

    /**
     * Gibt das Panel dieses Subwerkzeugs zurück.
     * 
     * @ensure result != null
     */
    public Pane getUIPane()
    {
        return _ui.getUIPane();
    }
}
