import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
//Die in den Testfällen verwendeten assert-Anweisungen werden über
//einen sogenannten statischen Import bereitgestellt, zum Beispiel:
//import static org.junit.Assert.assertEquals;
//
// Um die Annotation @Test verwenden zu können, muss diese importiert
// werden: import org.junit.Test;

import junit.framework.Assert;

/**
 * Diese Klasse testet die Implementation des VerleihService.
 */
public class VerleihServiceImplTest
{
    private Kunde _homer;
    private Kunde _roger;
    private Kunde _brian;
    private KundenstammService _kundenstamm;

    private Medium _abbey;
    private Medium _bad;
    private Medium _shape;
    private MedienbestandService _medienbestand;

    private VerleihServiceImpl _verleihService;
    
    
    
   
    private Kunde _kunde;
    
    private List<Medium> _medien;

    
    void setUp() {
    
        // Create a list of media to lend
        _medien = new ArrayList<>(); 
        _medien.add(new CD("CD2", "CD2", "Interpret2", 200));
        _medien.add(new DVD("DVD1", "DVD1", "Regisseur1", 100));
    }

    public VerleihServiceImplTest()
    {
        setUpKunden();
        setUpMedien();
        setUpVerleihService();
    }

    @Test
    // Alle Testmethoden erhalten die Annotation @Test. Dafür müssen diese nicht
    // mehr mit test im Namen beginnen. Dies wird jedoch aus Gewohnheit
    // oft weiter verwendet.
    public void testKundenstamm()
    {
        assertTrue(_verleihService.kundeImBestand(_homer));
        assertTrue(_verleihService.kundeImBestand(_roger));
        assertTrue(_verleihService.kundeImBestand(_brian));

        Kunde marge = new Kunde(Kundennummer.get(123459), "Marge", "Bouvier");
        assertFalse(_verleihService.kundeImBestand(marge));
    }

    @Test
    public void testAmAnfangIstNichtsVerliehen()
    {
        assertTrue(_verleihService.sindAlleNichtVerliehen(_medienbestand
                .getMedien()));
        for (Kunde kunde : _kundenstamm.getKunden())
        {
            assertTrue(_verleihService.istVerleihenMoeglich(kunde,
                    _medienbestand.getMedien()));
        }
    }

    @Test
    public void testNochEinTestFall1() //test verleihAn
    {
    	Datum d=new Datum(01, 04, 2000);
    	List<Medium> m =new ArrayList<Medium>();
    	m.add(_abbey);
    
    	_verleihService.verleiheAn(_homer,m,d);
    }
    
    
    @Test
    public void testnocheinfall() {
        
        List<Medium> medien = new ArrayList<Medium>();
       medien.add(_abbey);
        Datum ausleihDatum = new Datum(01, 04, 2000);
       
        
     
        
        _verleihService.verleiheAn(_homer, medien, ausleihDatum);
        assertTrue(_verleihService.getEntleiherFuer(_abbey).equals(_homer) );
       assertEquals(medien,_verleihService.getAusgelieheneMedienFuer(_homer));
       assertTrue( _verleihService.kundeImBestand(_homer));
    }
    
    
  //mit multiple media.
    @Test
    public void testVerleihNochEinFall() {
        Datum ausleihDatum = new Datum(20,05,2004);
        List<Medium> medien = new ArrayList<Medium>();
        medien.add(_abbey);
        medien.add(_bad);
        medien.add(_shape);

    	_verleihService.verleiheAn(_homer, medien, ausleihDatum);
    	
        assertEquals(_homer, _verleihService.getEntleiherFuer(_abbey));
        assertEquals(_homer, _verleihService.getEntleiherFuer(_shape));
        assertEquals(_homer, _verleihService.getEntleiherFuer(_bad));
        
    
    }
    

    
    @Test(expected = AssertionError.class)
    public void testConstructorWithInvalidInput()
    {
    	
    	Verleihkarte karte =new Verleihkarte(null,null,null);
    	_verleihService.verleiheAn(null,null,null);
    	
    }
    
   
    private void setUpKunden()
    {
        _homer = new Kunde(Kundennummer.get(123456), "Homer", "Simpson");
        _roger = new Kunde(Kundennummer.get(123457), "Roger", "Smith");
        _brian = new Kunde(Kundennummer.get(123458), "Brian", "Griffin");

        List<Kunde> testkunden = new ArrayList<Kunde>();
        testkunden.add(_homer);
        testkunden.add(_roger);
        testkunden.add(_brian);
        _kundenstamm = new KundenstammServiceImpl(testkunden);
    }

    private void setUpMedien()
    {
        _abbey = new CD("Abbey Road", "Meisterwerk", "Beatles", 44);
        _bad = new CD("Bad", "not as bad as the title might suggest",
                "Michael Jackson", 48);
        _shape = new CD("The Colour And The Shape", "bestes Album der Gruppe",
                "Foo Fighters", 46);

        List<Medium> _medien = new ArrayList<Medium>();
        _medien.add(_abbey);
        _medien.add(_bad);
        _medien.add(_shape);
        _medienbestand = new MedienbestandServiceImpl(_medien);
    }

    private void setUpVerleihService()
    {
        _verleihService = new VerleihServiceImpl(_kundenstamm, _medienbestand,
                new ArrayList<Verleihkarte>());
    
    }
    
    
   
    
}
