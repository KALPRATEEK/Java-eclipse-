public class Videospiel implements Medium {

    private String titel;

    private String _kommentar ;
    private String _system;

  
    //@require titel!=null
    // @require kommentar != null
  //@require  system!=leer
       
    
    public Videospiel(String titel, String kommentar,String system) {
    	 assert titel != null : "Titel darf nicht null sein";
         assert !titel.isEmpty() : "Titel darf nicht leer sein";
         assert kommentar != null : "Vorbedingung verletzt: kommentar != null";
         assert system != "" : "System darf nicht leer sein";
         assert system != null : "System darf nicht null sein";
        assert !system.isEmpty() : "System darf nicht leer sein";
         
        _kommentar = kommentar;
        this.titel = titel;
        _system=system;
    }

    @Override
    public String getKommentar() {
        return _kommentar;
    }

    @Override
    public String getMedienBezeichnung() {
        return "Videospiel";
    }
    
   
    @Override
    public String getTitel() {
        return titel;
    }
    
    
    public String getSystem() {
        return _system;
    }
    
    public String getFormatiertenString() {
        String format = "%s %s, %s";
        return String.format(format, getTitel(), getKommentar(), getSystem());
        		}


}