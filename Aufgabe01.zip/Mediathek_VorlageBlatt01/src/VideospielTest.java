import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.junit.Test;

    public class VideospielTest {
	  
    @Test
     public void testConstructor() {
    	
    	 Videospiel  spiel = new Videospiel("Super Mario Bros.", "best","Xbox");
        Assert.assertEquals("Super Mario Bros.", spiel.getTitel());
        Assert.assertEquals("Xbox", spiel.getSystem());
        Assert.assertEquals("best", spiel.getKommentar());
    }

    @Test(expected = AssertionError.class)
      public void testConstructorWithNullTitel() {
       Videospiel spiel= new Videospiel(null, "A classic platformer.",  "NES");
      }
  

    @Test(expected = AssertionError.class)
    public void testConstructorWithEmptySystem() {
   Videospiel  spiel=new Videospiel("Super Mario Bros.", "Bhenchod wahh",null );    
}
    
    
    @Test(expected = AssertionError.class)
    public void testConstructorWithNullComment() {
      Videospiel  spiel=new Videospiel("Super Mario Bros.",  null,"ps2");
     }
    }
